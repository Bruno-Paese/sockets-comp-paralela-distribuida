import socket

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(('', 60000))
server_socket.listen()
print('Aguardando conexão do cliente...')
connection, client_address = server_socket.accept()
try:
    while True:
        print('Cliente conectado:', client_address)
        data = connection.recv(1024)
        connection.send(data)
        print('Mensagem recebida:', data.decode())
        if data.decode() == 'sair':
            break
    print("Cliente solicitou desconexão")
    
except:
    print("Ocorreu uma exceção!")
finally:
    print("Saindo...")
    server_socket.close()
