import socket

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect(('127.0.0.1', 60000))
while(True):
    server_address_received = client_socket.getpeername()
    print(f"Conectado ao servidor: {server_address_received[0]}:{server_address_received[1]}")
    message = input('Digite uma mensagem para o servidor: ')
    client_socket.send(message.encode())
    data = client_socket.recv(1024)
    print(f'Mensagem recebida do servidor: {data.decode()}')
    if (message == 'sair'):
        break
print("Fechando conexão")
client_socket.close()

    

 
