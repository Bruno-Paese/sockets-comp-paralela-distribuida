import socket
import os

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(('localhost', 60000))
server_socket.listen()
print('Aguardando conexão do cliente...')

try:
    while True:
        connection, client_address = server_socket.accept()
        pid = os.fork()
        if pid == 0:  
            server_socket.close()  
            print(f'Cliente conectado: {client_address}')
            while True:
                data = connection.recv(1024)
                resposta = f"Recebi mensagem do cliente {client_address}"
                connection.send(resposta.encode())
                if data.decode() == 'sair':
                    print(f"{client_address} solicitou desconexão")
                    break
                else:
                    print(f'Mensagem recebida de {client_address}: {data.decode()}')
            os._exit(0)  
        else:
            connection.close() 
except KeyboardInterrupt:
    print("Solicitado encerramento do servidor via teclado")
    connection.close()
    server_socket.close()
