import socket 

server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_socket.bind(('', 12345))

print('Aguardando mensagens do cliente...')

while True:
    # Recebe a mensagem e o endereço do cliente
    data, endereco_cliente = server_socket.recvfrom(1024)
    print(f'Mensagem recebida de {endereco_cliente}: {data.decode()}')

    # Responde ao cliente
    resposta = f'Mensagem recebida com sucesso do cliente {endereco_cliente}!'
    server_socket.sendto(resposta.encode(), endereco_cliente)