import socket

client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
endereco_servidor = 'localhost', 12345

while True:
    mensagem = input('Digite uma mensagem para o servidor (ou digite "sair" para sair): ')

    if mensagem.lower() == 'sair':
        break

    # Envia a mensagem para o servidor
    client_socket.sendto(mensagem.encode(), endereco_servidor)

    # Recebe a resposta do servidor
    data, endereco = client_socket.recvfrom(1024)
    print(f'Resposta do servidor: {data.decode()}')

client_socket.close()