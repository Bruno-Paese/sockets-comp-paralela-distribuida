import socket

endereco_multicast = '224.0.0.1'  # Endereço multicast
porta = 12345  # Porta do grupo multicast

# Cria um socket UDP para multicast
server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Configura o socket para permitir múltiplas instâncias no mesmo grupo multicast
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

# Vincula o socket ao endereço multicast e à porta
server_socket.bind(('', porta))

# Configura a adesão ao grupo multicast
server_socket.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, socket.inet_aton(endereco_multicast) + socket.inet_aton('0.0.0.0'))

print(f'Aguardando mensagens do grupo multicast {endereco_multicast}:{porta}...')

while True:
    data, endereco_cliente = server_socket.recvfrom(1024)
    print(f'Mensagem de {endereco_cliente}: {data.decode()}')
