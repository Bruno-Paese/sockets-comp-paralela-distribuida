import socket

endereco_multicast = '224.0.0.1'  # Endereço multicast
porta = 12345  # Porta do grupo multicast

# Cria um socket UDP para multicast
client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Configura a adesão ao grupo multicast
client_socket.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, socket.inet_aton(endereco_multicast) + socket.inet_aton('0.0.0.0'))

while True:
    mensagem = input('Digite uma mensagem para o grupo multicast (ou digite "sair" para sair): ')

    if mensagem.lower() == 'sair':
        break

    # Envia a mensagem para o grupo multicast
    client_socket.sendto(mensagem.encode(), (endereco_multicast, porta))

client_socket.close()
